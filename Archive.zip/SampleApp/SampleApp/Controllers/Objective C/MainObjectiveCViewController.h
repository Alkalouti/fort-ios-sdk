//
//  MainObjectiveCViewController.h
//  SampleApp
//
//  Created by AlKalouti on 12/30/20.
//  Copyright © 2020 PayFort. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface MainObjectiveCViewController : UIViewController

@end

NS_ASSUME_NONNULL_END
